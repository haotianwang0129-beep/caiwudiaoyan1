#!/usr/bin/env python3
"""Portable Python export of aggregate tables; no respondent-level rows.
This reproduces values, not the exact formatting of the delivered JS workbook.
Usage: python export_aggregate_xlsx.py work/aggregate_tables.json output.xlsx
"""
import json,sys
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment

r=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'));out=Path(sys.argv[2]);out.parent.mkdir(parents=True,exist_ok=True)
w=Workbook();w.remove(w.active)
def add(name,rows):
    s=w.create_sheet(name[:31]);keys=list(dict.fromkeys(k for row in rows for k in row))
    s.append(keys)
    for row in rows:s.append([row.get(k) for k in keys])
    s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
    for c in s[1]:c.fill=PatternFill('solid',fgColor='193A54');c.font=Font(color='FFFFFF',bold=True)
    for col in s.columns:
        s.column_dimensions[col[0].column_letter].width=min(62,max(15,len(str(col[0].value))*2+5))
        for c in col:
            c.alignment=Alignment(wrap_text=True,vertical='top')
            if isinstance(c.value,float):c.number_format='0.0000'
    for row in s.iter_rows(min_row=2):
        for c in row:
            key=keys[c.column-1]
            if isinstance(c.value,(float,int)) and any(x in key for x in ['比例','选择率','首选率','入选率','计数比','Wilson']):c.number_format='0.0%'

for key,name in [('summary','总览'),('cross_tabs','探索性分组比较'),('pairwise','Q22配对比较'),('intersections','需求供给交集'),('headcount_quality','人数题质量'),('headcount_sensitivity','人数题敏感性'),('sensitivity','样本敏感性'),('quality','质量检查'),('dictionary','变量与追溯'),('benchmarks','基准核验')]:add(name,r[key])
for key,q in r['question_tables'].items():add('Q'+key+' '+q['type'],q['rows'])
w.save(out);print(out)
