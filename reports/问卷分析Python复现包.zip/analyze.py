#!/usr/bin/env python3
"""Reanalyse the two private survey exports. Writes aggregate statistics only.
Usage: python analyze.py --numeric numeric.xlsx --text text.xlsx --out aggregate
Do not publish the input workbooks or respondent-level data.
"""
import argparse, itertools, json, math, re
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats

BLOCKS={1:(6,8),2:(8,9),3:(9,10),4:(10,11),5:(11,12),6:(12,13),7:(13,14),8:(14,15),9:(15,16),10:(16,21),11:(21,36),12:(36,42),13:(42,43),14:(43,52),15:(52,53),16:(53,54),17:(54,62),18:(62,69),19:(69,78),20:(78,79),21:(79,86),22:(86,91),23:(91,97),24:(97,101),25:(101,109),26:(109,119),27:(119,124),28:(124,131),29:(131,132),30:(132,137),31:(137,138),32:(138,146),33:(146,151),34:(151,156),35:(156,162),36:(162,163),37:(163,168),38:(168,175),39:(175,179),40:(179,183),41:(183,184),42:(184,185),43:(185,192),44:(192,196),45:(196,200),46:(200,206),47:(206,207)}
MULTI={14,17,18,19,21,28,30,37,44,45,46}
RANK={23,25,38}; LIKERT={22,24,26,27,32,33,34,35,40,43}; BINARY={10,39}
TEXT_MAIN={14:43,17:46,18:47,19:48,21:50,23:56,25:61,28:77,30:79,37:106,38:107,44:125,45:126,46:127}
EMPTY={'','(空)','nan','None'}

def clean(s):
    s=re.sub(r'〖.*?〗','',str(s))
    return re.sub(r'^[A-Z][.．]','',s).strip()
def option(c):
    m=re.search(r'\(([A-Z][.．].*)\)$',c)
    return clean(m.group(1)) if m else c.split('—')[-1].strip()
def excelcol(i):
    s=''; i+=1
    while i: i,r=divmod(i-1,26); s=chr(65+r)+s
    return s
def ci(k,n):
    if not n:return [None,None]
    p=k/n; z=1.959963984540054; den=1+z*z/n
    a=(p+z*z/(2*n))/den; b=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [a-b,a+b]
def bh(ps):
    ps=np.asarray(ps,float); order=np.argsort(ps); ranked=ps[order]; q=np.minimum.accumulate((ranked*len(ps)/np.arange(1,len(ps)+1))[::-1])[::-1]; out=np.empty(len(ps));out[order]=np.minimum(q,1);return out.tolist()
def newcombe(a,n,b,m):
    p=a/n; q=b/m; l,u=ci(a,n); ll,uu=ci(b,m)
    return [p-q-math.sqrt((p-l)**2+(uu-q)**2),p-q+math.sqrt((u-p)**2+(q-ll)**2)]
def num(s):
    x=pd.to_numeric(s,errors='coerce'); return x.where((x>=0)&(x%1==0))
def missing(s):return s.isna()|s.astype(str).str.strip().isin(EMPTY)
def ratio(k,n):return float(k/n) if n else None
def serial(x):
    if isinstance(x,dict):return {str(k):serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [serial(v) for v in x]
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,float) and not math.isfinite(x):return None
    return x
def exact_signflip(d):
    # Exact paired randomization of the mean difference, retaining ties/zeroes.
    d=np.asarray(d,dtype=int); target=abs(int(d.sum())); weights=np.abs(d[d!=0]); dist={0:1.0}
    for w in weights:
        nxt={}
        for t,p in dist.items():
            nxt[t+int(w)]=nxt.get(t+int(w),0)+p/2
            nxt[t-int(w)]=nxt.get(t-int(w),0)+p/2
        dist=nxt
    return min(1.,sum(p for t,p in dist.items() if abs(t)>=target))

def run(numeric_path,text_path,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    n=pd.read_excel(numeric_path,sheet_name='Sheet1');t=pd.read_excel(text_path,sheet_name='Sheet1')
    assert n.shape==(162,207) and t.shape==(162,129),'Unexpected schema; review before using this script.'
    assert n.iloc[:,0].is_unique and t.iloc[:,0].is_unique
    t=t.set_index(t.columns[0]).loc[n.iloc[:,0]].reset_index();N=len(n)
    titles={}; tables={}; dictionary=[]; quality=[]; checks=[]; mappings={}
    # Align and independently reconstruct exported codes from the text export.
    checked=0; mismatches=0
    for q,(lo,hi) in BLOCKS.items():
        if q in TEXT_MAIN:title=t.columns[TEXT_MAIN[q]]
        else:title=n.columns[lo]
        titles[q]=title
        kind='多选' if q in MULTI else '前三排序' if q in RANK else '五级量表' if q in LIKERT else '是非矩阵' if q in BINARY else '选填人数' if q in {11,12} else '开放建议' if q==47 else '地域' if q==1 else '单选'
        rows=[]
        for j in range(lo,hi):
            c=n.columns[j]; src=f'数值版 Sheet1!{excelcol(j)}2:{excelcol(j)}{N+1}'
            dictionary.append({'题号':f'Q{q}','类型':kind,'原始字段':c,'数据范围':src,'公开处理':'仅公开主题汇总，不含原文' if q==47 else '城市不公开，仅省级汇总' if q==1 and j==7 else '仅汇总'})
            if q in MULTI|RANK:
                tc=t.iloc[:,TEXT_MAIN[q]].astype(str); letter=re.search(r'\(([A-Z])[.．]',c).group(1)
                if q in MULTI:
                    rec=tc.map(lambda s:int(any(z.startswith(letter+'.') for z in s.split('┋')))); orig=pd.to_numeric(n.iloc[:,j],errors='coerce').fillna(0)
                else:
                    rec=tc.map(lambda s:next((k+1 for k,z in enumerate(s.split('→')) if z.startswith(letter+'.')),0));orig=pd.to_numeric(n.iloc[:,j],errors='coerce').fillna(0)
                mismatches+=int((rec.to_numpy()!=orig.to_numpy()).sum());checked+=N
            elif c in t.columns:
                a=n[c];b=t[c]
                if q in {1,11,12,47}:
                    def norm(v):
                        if pd.isna(v) or str(v).strip() in EMPTY:return ''
                        return str(v).strip()
                    eq=np.array([norm(x)==norm(y) for x,y in zip(a,b)])
                    # Q47 text export carries labels while numeric carries code plus free text.
                    if q==47:
                        eq=np.array([str(x).split('〖')[0].split('.')[0]==str(y).split('〖')[0].split('.')[0] for x,y in zip(a,b)]) if False else np.array([str(x)==str(y) for x,y in zip(a,b)])
                elif q in LIKERT:
                    eq=pd.to_numeric(a,errors='coerce').to_numpy()==pd.to_numeric(b,errors='coerce').to_numpy()
                else:
                    vals={}
                    for x,y in zip(a,b):
                        label=re.sub(r'〖.*?〗','',str(y)); vals.setdefault(str(x),set()).add(label)
                    assert all(len(v)==1 for v in vals.values()),f'Inconsistent label map Q{q}'
                    mappings[j]={k:list(v)[0] for k,v in vals.items()}
                    rec=[]
                    for y in b:
                        ss=re.sub(r'〖.*?〗','',str(y))
                        if q in BINARY:rec.append(1 if ss=='是' else 2 if ss=='否' else np.nan)
                        else:
                            m=re.match(r'([A-Z])[.．]',ss);rec.append(ord(m.group(1))-64 if m else np.nan)
                    eq=pd.to_numeric(a,errors='coerce').to_numpy()==np.array(rec)
                mismatches+=int((~eq).sum());checked+=N
        if q==1:
            for label,k in n.iloc[:,lo].astype(str).str.replace(r'(省|市)$','',regex=True).value_counts().items():rows.append({'选项':label,'人数':int(k),'分母':N,'比例':k/N})
            note='仅按省份汇总，统一去除省、市后缀（如江苏省与江苏合并）；不发布城市或省份与个人特征交叉组合，不能据省份数量推断地区代表性。'
        elif q in {11,12}:
            for j in range(lo,hi):
                s=n.iloc[:,j];v=num(s);valid=v.dropna()
                rows.append({'项目':option(n.columns[j]),'有效填报数':int(v.notna().sum()),'空白数':int(missing(s).sum()),'非空无效数':int((~missing(s)&v.isna()).sum()),'零值数':int((v==0).sum()),'计数合计':float(valid.sum()),'均值':float(valid.mean()),'中位数':float(valid.median()),'第一四分位':float(valid.quantile(.25)),'第三四分位':float(valid.quantile(.75)),'最小值':float(valid.min()),'最大值':float(valid.max())})
            note='每列使用各自有效非负整数记录；空白与非数值分别报告。计数合计未经医院去重，不能视为独立人员总量。Q12明确允许同人多证。'
        elif q in MULTI:
            for j in range(lo,hi):
                k=int((n.iloc[:,j]==1).sum());rows.append({'选项':option(n.columns[j]),'选择人数':k,'分母':N,'选择率':k/N,'Wilson95下限':ci(k,N)[0],'Wilson95上限':ci(k,N)[1]})
            note='分母为全部162份答卷；多选比例之和可超过100%。未勾选不能等同独立核实没有。'
            totals=(n.iloc[:,lo:hi]==1).sum(axis=1);limit={14:3,19:4,46:3}.get(q)
            quality.append({'项目':f'Q{q} 多选完整性','结果':f'每份选择 {totals.min()} 至 {totals.max()} 项；零项 {int((totals==0).sum())} 份；超上限 {int((totals>limit).sum()) if limit else 0} 份'})
        elif q in RANK:
            for j in range(lo,hi):
                s=n.iloc[:,j];counts=[int((s==k).sum()) for k in [1,2,3]];k=sum(counts)
                rows.append({'选项':option(n.columns[j]),'第1名':counts[0],'第2名':counts[1],'第3名':counts[2],'前三入选人数':k,'分母':N,'首选率':counts[0]/N,'前三入选率':k/N,'321加权分':3*counts[0]+2*counts[1]+counts[2]})
            valid=n.iloc[:,lo:hi].apply(lambda x:sorted(pd.to_numeric(x,errors='coerce').dropna().tolist())==[1,2,3],axis=1)
            quality.append({'项目':f'Q{q} 排序约束','结果':f'{int(valid.sum())}/{N} 份恰含唯一名次1、2、3'})
            note='首选率与前三入选率分别报告；3、2、1加权分仅为透明描述性排序，不是问卷原有量表或已验证效用。'
        elif q in LIKERT:
            for j in range(lo,hi):
                s=pd.to_numeric(n.iloc[:,j],errors='coerce');valid=s[s.between(1,5)];nv=len(valid);high=int((valid>=4).sum()); low=int((valid<=2).sum())
                rows.append({'子项':option(n.columns[j]),'有效数':nv,'1分':int((valid==1).sum()),'2分':int((valid==2).sum()),'3分':int((valid==3).sum()),'4分':int((valid==4).sum()),'5分':int((valid==5).sum()),'均值':float(valid.mean()),'标准差':float(valid.std()),'中位数':float(valid.median()),'4至5分人数':high,'4至5分比例':high/nv,'1至2分人数':low,'1至2分比例':low/nv,'Wilson95下限':ci(high,nv)[0],'Wilson95上限':ci(high,nv)[1]})
            note='保留完整五级分布，均值为辅助描述。Q22高分代表差距较大；Q35高分代表通道较畅通；其余各题以原题锚点解释。不同量表不能简单合并为人才能力总分。'
        elif q in BINARY:
            for j in range(lo,hi):
                k=int((n.iloc[:,j]==1).sum());rows.append({'项目':option(n.columns[j]),'是':k,'否':int((n.iloc[:,j]==2).sum()),'分母':N,'是比例':k/N})
            note='数值编码1=是、2=否，已与文本版交叉核对。'
        elif q==47:
            s=t.iloc[:,-1].astype(str);has=s.str.startswith('B.');texts=s[has].tolist()
            # Rule-based multi-label coding. Deliberately no respondent ID or verbatim text exported.
            patterns={'治理与组织支持':'内审|组织架构|归口|统一管理|培训制度|上层文件|机制建设|领导的认可','职业发展与公平激励':'待遇|发展路径|职称|任人唯亲','实践应用':'所学用到|跟岗','经费或学习实践机会':'经费|更多机会','协同与案例共享':'联动|案例分享'}
            for name,pat in patterns.items():
                k=sum(bool(re.search(pat,x)) for x in texts);rows.append({'主题':name,'涉及意见数':k,'实质意见分母':len(texts),'意见内比例':k/len(texts)})
            note=f'实质意见{len(texts)}份，其他{N-len(texts)}份；关键词辅助、逐条人工复核的多标签探索性编码，主题可重叠，不公开原文或答卷标识；比例不能外推至全样本。'
        else:
            j=lo;s=n.iloc[:,j]; labels=mappings[j]
            for code,k in s.value_counts().sort_index().items():
                rows.append({'编码':int(code),'选项':clean(labels[str(code)]),'人数':int(k),'分母':N,'比例':k/N,'Wilson95下限':ci(k,N)[0],'Wilson95上限':ci(k,N)[1]})
            note='按原题编码和文本标签统计；其他选项中的填写内容不公开。仅展示本样本实际出现的编码。'
        tables[q]={'title':title,'type':kind,'note':note,'rows':rows,'source':('文本版 Sheet1!DY2:DY163；数值版GY2:GY163仅用于有无意见计数' if q==47 else f'数值版 Sheet1!{excelcol(lo)}2:{excelcol(hi-1)}{N+1}')}
    # Q47 numeric export is coded rather than identical text: check its choice and bracketed content privately.
    # Remove the prior raw-string discrepancy and reconstruct A=1 / B=2.
    q47n=n.iloc[:,206].astype(str);q47t=t.iloc[:,-1].astype(str)
    raw_mismatch=int((q47n.to_numpy()!=q47t.to_numpy()).sum())
    q47rec=q47t.map(lambda x: '1' if x.startswith('A.') else '2' if x.startswith('B.') else '')
    real_mismatch=int((q47n.to_numpy()!=q47rec.to_numpy()).sum())
    mismatches=mismatches-raw_mismatch+real_mismatch
    quality[:0]=[{'项目':'输入结构','结果':f'同批答卷 {N} 份；数值版207列，文本版129列；47题'}, {'项目':'对齐键','结果':'两份序号均唯一，按序号对齐；不发布序号'}, {'项目':'题目字段跨导出核验','结果':f'{checked} 格；不一致 {mismatches} 格'}, {'项目':'主样本','结果':'保留全部162份；Q11、Q12选答缺失不整行剔除'}]
    quality += [{'项目':'Q28并选核查','结果':f'尚无合作与具体合作形式同时选择 {int(((n.iloc[:,130]==1)&(n.iloc[:,124:130]==1).any(axis=1)).sum())} 份，标为潜在矛盾，主分析保留'}, {'项目':'Q30并选核查','结果':f'尚无系统评估与具体评价方式同时选择 {int(((n.iloc[:,136]==1)&(n.iloc[:,132:136]==1).any(axis=1)).sum())} 份，可能为零散评价未成体系，不判定完全没有评价'}]
    # Core outcomes and conditional intersections.
    outcomes={
      '业务能力高差距':n.iloc[:,86]>=4,'财务能力高差距':n.iloc[:,87]>=4,'管理能力高差距':n.iloc[:,88]>=4,'数据能力高差距':n.iloc[:,89]>=4,'风险能力高差距':n.iloc[:,90]>=4,
      '数智课程高需求':n.iloc[:,116]>=4,'跟岗进入前三':n.iloc[:,102].isin([1,2,3]),'无系统评估':n.iloc[:,136]==1,
      '制度落实到位':n.iloc[:,52]==1,'常态化轮岗':n.iloc[:,183]==1,'人员配置不足':n.iloc[:,42].isin([1,2]),'培训经费前两档':n.iloc[:,162].isin([1,2])}
    summary=[]
    def add(label,mask,den=None,source=''):
        if den is None:den=pd.Series(True,index=n.index)
        k=int((mask&den).sum());Nn=int(den.sum());l,u=ci(k,Nn);summary.append({'指标':label,'人数':k,'分母':Nn,'比例':k/Nn,'Wilson95下限':l,'Wilson95上限':u,'来源':source})
    for label,mask in outcomes.items():add(label,mask)
    add('三级医院类别',n.iloc[:,8].isin([1,2]));add('二级医院类别',n.iloc[:,8].isin([3,4]));add('管理者 Q4编码1至4',n.iloc[:,10].isin([1,2,3,4]));add('院领导及总会计师 Q4编码1至2',n.iloc[:,10].isin([1,2]));add('硕士',n.iloc[:,12]==2);add('本科',n.iloc[:,12]==3);add('高级职称',n.iloc[:,14].isin([1,2]));add('财务或审计部门',n.iloc[:,9].isin([2,3]));add('财会审计专业',n.iloc[:,13]==1)
    for label,idx in [('现有数据工具培训',58),('缺乏培训后跟踪',70),('分层分类不足',72),('实践项目机会不足',201),('激励结果运用障碍',202),('已有跟岗轮岗培训',65)]:add(label,n.iloc[:,idx]==1)
    demand=outcomes['数智课程高需求']; supply=n.iloc[:,58]==1;placement=outcomes['跟岗进入前三'];existing=n.iloc[:,65]==1
    add('高数智需求且未报告现有数据工具培训',demand&~supply,source='Q26 F8 × Q17 E；近似概念匹配')
    add('高数智需求群体中的未报告现有数据工具培训',~supply,demand,source='Q26 F8 × Q17 E；近似概念匹配')
    add('偏好跟岗且未报告已有跟岗轮岗方式',placement&~existing,source='Q25 B × Q18 D；近似概念匹配')
    intersections=[]
    for label,a,b in [('数智需求与现有数据工具培训',demand,supply),('跟岗偏好与已有跟岗轮岗方式',placement,existing)]:
        for av,bv in itertools.product([True,False],repeat=2):
            k=int(((a==av)&(b==bv)).sum());intersections.append({'配对':label,'需求或偏好':av,'报告现有供给':bv,'人数':k,'分母':N,'比例':k/N})
    # Exploratory contrast families, each BH-adjusted separately.
    cross=[]
    def family(name,g1,g0,ends,labels):
        start=len(cross)
        for label,y in ends.items():
            a=int((g1&y).sum());b=int((g0&y).sum());N1=int(g1.sum());N0=int(g0.sum());p=stats.fisher_exact([[a,N1-a],[b,N0-b]]).pvalue;l,u=newcombe(a,N1,b,N0)
            cross.append({'检验家族':name,'结局':label,'组1':labels[0],'组0':labels[1],'组1事件':a,'组1分母':N1,'组0事件':b,'组0分母':N0,'组1比例':a/N1,'组0比例':b/N0,'比例差':a/N1-b/N0,'差95下限':l,'差95上限':u,'Fisher双侧p':p})
        qs=bh([r['Fisher双侧p'] for r in cross[start:]])
        for row,qv in zip(cross[start:],qs):row['BH q']=qv
    family('医院类别12项',n.iloc[:,8].isin([1,2]),n.iloc[:,8].isin([3,4]),outcomes,['三级类别','二级类别'])
    family('职务分组12项',n.iloc[:,10].isin([1,2,3,4]),n.iloc[:,10]==5,outcomes,['Q4编码1至4','Q4其他'])
    impl=n.iloc[:,52]==1
    family('制度落实3项',impl,~impl,{'无系统评估':outcomes['无系统评估'],'缺乏培训后跟踪':n.iloc[:,70]==1,'激励结果运用障碍':n.iloc[:,202]==1},['有制度且落实到位','其他回答'])
    validtotal=num(n.iloc[:,21]).notna()
    family('Q11可用性6项',validtotal,~validtotal,{'三级类别':n.iloc[:,8].isin([1,2]),'管理者':n.iloc[:,10].isin([1,2,3,4]),'硕士及以上':n.iloc[:,12].isin([1,2]),'高级职称':n.iloc[:,14].isin([1,2]),'财审专业':n.iloc[:,13]==1,'数智课程高需求':demand},['Q11总人数有效','其余答卷'])
    # Within-person ordinal gap comparisons.
    gap=n.iloc[:,86:91].astype(int);fr=stats.friedmanchisquare(*(gap.iloc[:,j] for j in range(5)));pair=[]
    for i,j in itertools.combinations(range(5),2):
        d=(gap.iloc[:,i]-gap.iloc[:,j]).to_numpy();se=d.std(ddof=1)/math.sqrt(N);p=exact_signflip(d)
        pair.append({'维度1':option(n.columns[86+i]),'维度2':option(n.columns[86+j]),'配对数':N,'均值差':float(d.mean()),'均值差95下限':float(d.mean()-stats.t.ppf(.975,N-1)*se),'均值差95上限':float(d.mean()+stats.t.ppf(.975,N-1)*se),'差大于0':int((d>0).sum()),'差等于0':int((d==0).sum()),'差小于0':int((d<0).sum()),'精确符号置换p':p})
    for r,qv in zip(pair,bh([r['精确符号置换p'] for r in pair])):r['BH q']=qv
    friedman={'统计量':float(fr.statistic),'自由度':4,'p':float(fr.pvalue),'Kendall W':float(fr.statistic/(N*4))}
    # Optional headcounts, separate valid-case sets and explicit sensitivity only.
    head=[];person=[];total=num(n.iloc[:,21]);q1=total.quantile(.25);q3=total.quantile(.75);cut=q3+1.5*(q3-q1)
    for q in [11,12]:
        lo,hi=BLOCKS[q];block=n.iloc[:,lo:hi];valid=block.apply(num);nonempty=~block.apply(missing)
        for label,k in [('任一非空',nonempty.any(axis=1).sum()),('任一有效数值',valid.notna().any(axis=1).sum()),('全部字段有效',valid.notna().all(axis=1).sum()),('整题空白',(~nonempty.any(axis=1)).sum())]:head.append({'题号':f'Q{q}','口径':label,'答卷数':int(k),'分母':N})
    s=total.dropna().sort_values(ascending=False)
    for remove in range(4):head.append({'题号':'Q11','口径':f'仅去除最大{remove}条总人数记录的情景','答卷数':len(s)-remove,'填报计数合计':float(s.iloc[remove:].sum()),'分母':None})
    head.append({'题号':'Q11','口径':'总人数IQR上界','答卷数':None,'填报计数合计':float(cut),'分母':None})
    for name,inds in [('学历',range(22,26)),('职称',range(26,30)),('专业',range(30,36))]:
        vv=n.iloc[:,list(inds)].apply(num);complete=total.notna()&vv.notna().all(axis=1);equal=complete&(vv.sum(axis=1)==total)
        for scenario,mask in [('分项完整',complete),('分项和等于总人数',equal),('相等且总人数不超IQR上界',equal&(total<=cut))]:
            den=float(total[mask].sum())
            for j in inds:
                k=float(num(n.iloc[:,j])[mask].sum());person.append({'结构':name,'敏感性情景':scenario,'项目':option(n.columns[j]),'有效答卷数':int(mask.sum()),'项目填报计数':k,'同记录总人数计数':den,'计数比':ratio(k,den)})
    # Response-quality and geographic-composition sensitivity. No row deletion in main analysis.
    allscale=n.iloc[:,[j for q in LIKERT for j in range(*BLOCKS[q])]].astype(float)
    seconds=n.iloc[:,2].astype(str).str.extract(r'(\d+)')[0].astype(float);fast=seconds<300;straight=allscale.nunique(axis=1)==1;flags=fast|straight
    quality += [{'项目':'59个量表子项','结果':f'小于300秒 {int(fast.sum())} 份；所有量表同分 {int(straight.sum())} 份；合并标记 {int(flags.sum())} 份，仅用于敏感性'}, {'项目':'Q11总人数有效性','结果':f'有效 {int(validtotal.sum())} 份，其余 {int((~validtotal).sum())} 份；后者包含空白和非数值，不等于整题空白'}]
    sensitivity=[]
    masks={'全样本':pd.Series(True,index=n.index),'剔除快速或全量表同分':~flags,'去除江苏与河南':~n.iloc[:,6].astype(str).str.contains('江苏|河南')}
    senends={'数智课程高需求':demand,'跟岗进入前三':placement,'缺乏培训后跟踪':n.iloc[:,70]==1,'业务能力高差距':outcomes['业务能力高差距'],'数据能力高差距':outcomes['数据能力高差距'],'无系统评估':outcomes['无系统评估']}
    for sc,mask in masks.items():
        for lab,y in senends.items():sensitivity.append({'情景':sc,'指标':lab,'人数':int((mask&y).sum()),'分母':int(mask.sum()),'比例':float((mask&y).sum()/mask.sum())})
    # Pre-specified regression checks from the earlier verified public aggregate.
    benchmarks={'三级类别':(int(n.iloc[:,8].isin([1,2]).sum()),145),'硕士':(int((n.iloc[:,12]==2).sum()),88),'管理者':(int(n.iloc[:,10].isin([1,2,3,4]).sum()),91),'数智高需求':(int(demand.sum()),156),'数智需求供给交集':(int((demand&~supply).sum()),109),'跟岗前三':(int(placement.sum()),125),'Q11总人数有效':(int(total.notna().sum()),98),'Q11计数合计':(int(total.sum()),12573)}
    for key,(actual,expected) in benchmarks.items():checks.append({'检查':key,'本次重算':actual,'已核验汇总基准':expected,'一致':actual==expected})
    result={'metadata':{'N':N,'questions':47,'date':'2026-10-17','public_only':True,'matching_cells':checked,'matching_mismatches':mismatches,'units':'答卷/受访者；非去重医院。比例区间和检验均为模型条件下的探索性推断，不是全国估计。','confidence':'Wilson比例区间；Newcombe独立两比例差区间；配对均值差t区间未作多重性调整。'},'question_tables':tables,'summary':summary,'intersections':intersections,'cross_tabs':cross,'pairwise':pair,'friedman':friedman,'headcount_quality':head,'headcount_sensitivity':person,'sensitivity':sensitivity,'quality':quality,'dictionary':dictionary,'benchmarks':checks}
    (out/'aggregate_tables.json').write_text(json.dumps(serial(result),ensure_ascii=False,indent=2),encoding='utf-8')
    for key in ['summary','cross_tabs','pairwise','headcount_quality','headcount_sensitivity','sensitivity','quality','dictionary','benchmarks']:
        pd.DataFrame(result[key]).to_csv(out/f'{key}.csv',index=False,encoding='utf-8-sig')
    print(json.dumps({'rows':N,'question_tables':len(tables),'matched_cells':checked,'mismatches':mismatches,'benchmark_all_pass':all(x['一致'] for x in checks),'friedman':friedman,'business_data_pair':pair[2],'output':str(out/'aggregate_tables.json')},ensure_ascii=False,indent=2))
    return result

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--numeric',required=True);p.add_argument('--text',required=True);p.add_argument('--out',default='aggregate');a=p.parse_args();run(a.numeric,a.text,a.out)
