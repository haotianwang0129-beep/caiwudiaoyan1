#!/usr/bin/env python3
"""Create the public, aggregate-only Chinese report from analyze.py output."""
import json, re, sys, math, textwrap
from pathlib import Path
from xml.sax.saxutils import escape
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_CENTER
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image,KeepTogether
from reportlab.lib.pagesizes import A4
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
DATA=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'work/aggregate_tables.json'
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'deliverables'
OUT.mkdir(parents=True,exist_ok=True);FIG=ROOT/'work/figures';FIG.mkdir(parents=True,exist_ok=True)
R=json.loads(DATA.read_text());Q=R['question_tables'];N=R['metadata']['N']
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':'Noto Sans CJK JP','axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.edgecolor':'#CAD3DC','savefig.facecolor':'white'})
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='CN',fontName='STSong-Light',fontSize=10.5,leading=17,spaceAfter=7,wordWrap='CJK'))
styles.add(ParagraphStyle(name='SmallCN',parent=styles['CN'],fontSize=8.5,leading=12,spaceAfter=5,textColor=colors.HexColor('#525E6B')))
styles.add(ParagraphStyle(name='CellCN',parent=styles['CN'],fontSize=8.5,leading=12,spaceAfter=0))
styles.add(ParagraphStyle(name='HeadCellCN',parent=styles['CellCN'],textColor=colors.white))
styles.add(ParagraphStyle(name='TitleCN',parent=styles['CN'],fontSize=26,leading=37,spaceAfter=18))
styles.add(ParagraphStyle(name='H1CN',parent=styles['CN'],fontSize=17,leading=24,spaceBefore=14,spaceAfter=10,keepWithNext=True))
styles.add(ParagraphStyle(name='H2CN',parent=styles['CN'],fontSize=12.5,leading=19,spaceBefore=12,spaceAfter=7,keepWithNext=True))
doc=Document();sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=Inches(.72);sec.bottom_margin=Inches(.65);sec.left_margin=Inches(.75);sec.right_margin=Inches(.75)
for name in ['Normal','Title','Heading 1','Heading 2','Heading 3','Caption']:
    s=doc.styles[name];s.font.name='Noto Sans CJK SC';s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');s.font.color.rgb=RGBColor(0,0,0)
doc.styles['Normal'].font.size=Pt(10);doc.styles['Normal'].paragraph_format.line_spacing=1.22;doc.styles['Normal'].paragraph_format.space_after=Pt(6)
doc.styles['Title'].font.size=Pt(25);doc.styles['Heading 1'].font.size=Pt(17);doc.styles['Heading 2'].font.size=Pt(12.5)
for sty in doc.styles:
    if sty._element.pPr is not None:
        for border in list(sty._element.pPr.findall(qn('w:pBdr'))):sty._element.pPr.remove(border)
doc.styles['Caption'].font.bold=False;doc.styles['Caption'].font.size=Pt(8.5)
header=sec.header.paragraphs[0];header.text='卫生健康经济管理人才培养调查';header.style='Caption'
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
footer.add_run('汇总公开版  |  ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
story=[];plain=[]
def p(txt,small=False):
    txt=str(txt).replace('−','-');story.append(Paragraph(escape(txt).replace('\n','<br/>'),styles['SmallCN' if small else 'CN']));doc.add_paragraph(txt,style='Caption' if small else 'Normal');plain.append(txt)
def h(txt,level=1):
    story.append(Paragraph(escape(txt),styles[f'H{level}CN']));doc.add_heading(txt,level=level);plain.append(txt)
def page():story.append(PageBreak());doc.add_page_break()
def table(headers,rows,widths=None):
    if not rows:return
    widths=widths or [1/len(headers)]*len(headers)
    if sum(widths)>1.1:widths=[x/sum(widths) for x in widths]
    formatted=[[str(x) if x is not None else '—' for x in row] for row in rows]
    cells=[[Paragraph(escape(str(x)),styles['HeadCellCN']) for x in headers]]+[[Paragraph(escape(x),styles['CellCN']) for x in row] for row in formatted]
    tb=Table(cells,colWidths=[481*x for x in widths],repeatRows=1,hAlign='LEFT')
    tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#193A54')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#D9D9D9')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F1F5F8')])]))
    story.extend([tb,Spacer(1,9)])
    tbw=doc.add_table(rows=1,cols=len(headers));tbw.autofit=False
    for i,col in enumerate(tbw.columns):col.width=Inches(7*widths[i])
    for i,(cell,name) in enumerate(zip(tbw.rows[0].cells,headers)):
        cell.text=str(name);cell.width=Inches(7*widths[i]);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'193A54');cell._tc.get_or_add_tcPr().append(sh)
        for rr in cell.paragraphs[0].runs:rr.font.color.rgb=RGBColor(255,255,255);rr.font.bold=True
    repeat=OxmlElement('w:tblHeader');tbw.rows[0]._tr.get_or_add_trPr().append(repeat)
    for ri,row in enumerate(formatted):
        cs=tbw.add_row().cells
        for i,(cell,value) in enumerate(zip(cs,row)):
            cell.text=value;cell.width=Inches(7*widths[i])
            if ri%2==1:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'F1F5F8');cell._tc.get_or_add_tcPr().append(sh)
    for row in tbw.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                para.paragraph_format.space_after=Pt(3);para.paragraph_format.space_before=Pt(3)
                for rr in para.runs:rr.font.size=Pt(8.5)
            pr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
            for edge in ['top','left','bottom','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
            pr.append(borders)
    doc.add_paragraph('');plain.append(' | '.join(headers));plain.extend(' | '.join(x) for x in formatted)
def pct(x):return f'{100*x:.1f}%'
def pf(x):return f'{x:.3g}' if x<.001 else f'{x:.4f}'
def bar(name,labels,values,title,source,second=None):
    height=max(2.65,0.33*len(labels)+.65);fig,ax=plt.subplots(figsize=(7.6,height));yy=list(range(len(labels)))
    if second is None:
        ax.barh(yy,values,color='#245A7A',height=.62)
        for y,v in zip(yy,values):ax.text(v+1,y,f'{v:.1f}%',va='center',fontsize=9)
    else:
        ax.barh([y-.18 for y in yy],values,height=.32,color='#245A7A',label='前三入选率')
        ax.barh([y+.18 for y in yy],second,height=.32,color='#A8C2D3',label='首选率');ax.legend(loc='lower right',frameon=False)
    ax.set_yticks(yy,[textwrap.fill(x,18) for x in labels]);ax.invert_yaxis();ax.set_xlim(0,112);ax.set_xticks([0,20,40,60,80,100],[f'{x}%' for x in [0,20,40,60,80,100]]);ax.grid(axis='x',alpha=.17);ax.set_axisbelow(True);ax.tick_params(axis='y',length=0);fig.tight_layout()
    path=FIG/f'{name}.png';fig.savefig(path,dpi=180,bbox_inches='tight');plt.close(fig)
    h(title,2);img=Image(str(path),width=470,height=470*height/7.6);story.append(img);doc.add_picture(str(path),width=Inches(6.8));p(source,True)

story.append(Spacer(1,66));story.append(Paragraph('业财融合视域下<br/>卫生健康经济管理人才培养<br/>调查分析报告',styles['TitleCN']))
doc.add_paragraph('业财融合视域下\n卫生健康经济管理人才培养\n调查分析报告',style='Title')
p('162份答卷的完整重算与证据复核')
p('研究对象：受访者本人特征、所在机构培养现状、能力与课程需求、实践路径及保障机制。')
p('本报告面向人才培养项目设计与管理决策。问卷显示数智与业务能力培养需求突出，跟岗、项目与案例学习具有较高偏好；落实制度、过程跟踪及成果运用仍存在改进空间。所有结论均限定于本次答卷，不等同于独立医院调查或全国总体估计。')
p('分析日期  2026年10月17日')
p('公开汇总版  不含原始答卷、个人标识、IP、逐人时间或可识别开放原文',True)
p('基于原始两份Excel重新计算。本版独立生成，不宣称恢复此前无法取得的报告二进制文件。',True)
page();h('阅读导航')
for a in ['一 主要结论与决策含义','二 数据基础与分析方法','三 受访者结构与机构培养现状','四 复合能力差距与人才需求','五 培养方式及课程供需','六 组织保障与成果转化','七 探索性比较与不确定性','八 人员结构选答的专门核验','九 稳健性与旧结论检查','十 可执行建议与后续研究','附录A 47题完整统计','附录B 完整比较与追溯说明']:p(a)
p('使用顺序：先看主要结论，再查看对应原题和分母；需要引用数值时以本报告与配套统计工作簿同口径结果为准。附件代码可在本地读取原始输入后重新产生公开聚合结果。',True)
page();h('一 主要结论与决策含义')
p('最明确的需求是数智课程与业务实践的结合。Q26数智化运营与数据分析必要程度达到4至5分的有156/162份（96.3%），但Q17报告已有信息化与数据工具培训的仅49/162份（30.2%）。同一答卷中同时满足高需求且未勾选现有供给的有109份，占全样本67.3%，占高需求者69.9%。两个题项概念接近但不完全相同，不能直接解释为109家医院完全没有数据培训。')
p('当前能力差距呈现业务、数据与管理相对突出，财务相对较小的格局。业务高差距66份（40.7%），数据57份（35.2%），财务42份（25.9%）。业务与数据的配对差异未获得明确统计支持，不能把两者机械排序为显著不同的优先级。')
table(['问题','证据','决策含义'],[
 ['人才供需','未来需求前三：运营133、数据120、综合89份','用运营项目承载数据与业务课程，兼顾综合协调'],
 ['实践方式','跟岗前三125、项目95、案例90份','优先试点可交付真实成果的实践组合'],
 ['过程管理','缺跟踪108份；分层不足82份','加入阶段复盘与分层任务设计'],
 ['成果转化','实践机会不足126份；激励障碍96份','设置真实项目入口及结果运用机制'],
 ['制度关联','制度落实组无评估9/32，其他组76/130','将制度建设与实际评价工具同时推进']],[.18,.40,.42])
p('这些结果支持“优先试点什么”，尚不能证明“某种培养方式最有效”。偏好、必要性与现有供给属于不同测量对象；有效性需要培训前后指标、对照或分阶段实施评价。')
h('需要保留的三条边界',2)
p('第一，162份答卷不等于162家独立医院，缺少医院唯一标识，不能去重或处理院内聚类。第二，样本高度集中于三级类别与财审背景，基层覆盖不足。第三，Q11和Q12为选答，人数合计受异常大值、重复机构和填报口径影响，不构成可靠的独立人员样本。')
page();h('二 数据基础与分析方法')
p('原始数据为同一问卷的两个导出版本，均为Sheet1和162行。数值版207列，文本版129列，含47题。按答卷序号对齐后，对201个实质字段进行重建与交叉比较，共32562格一致。多选按文本选项拆解，排序按箭头顺序重建，单选按选项字母或是非标签重建。元数据和标识仅用于内部匹配，不进入公开附件。')
p('参考PDF《高端会计人才项目在线学习情况调研报告》为另一项1495份答卷的调查，仅借鉴“样本画像—现状—需求—建议”的结构，不迁用其中任何样本数、比例或研究结论。本报告使用当前162份真实数据重新分析。')
table(['题型','处理规则','分母'],[['单选与是非矩阵','按原始代码及文本标签汇总','本次均为162'],['多选题','每项单独计算选择人数；比例可累计超过100%','162'],['Q23 Q25 Q38前三排序','分别列第1、第2、第3名、首选率与前三率','162'],['五级量表','报告1至5分分布、均值、标准差、中位数及高低分率','各子项有效数，本次162'],['Q11 Q12人数选答','非负整数为有效；空白与非空无效分开','每字段自己的有效填报数'],['Q47开放题','12份实质意见，多主题编码，仅公开聚合','12份实质意见']],[.23,.53,.24])
h('统计推断与多重比较',2)
p('二元比例采用Wilson 95%区间。探索性分组比较采用双侧Fisher精确检验，比例差采用Newcombe 95%区间。分别在医院类别12项、职务分组12项、制度落实3项与Q11可用性6项家族内实施Benjamini–Hochberg校正。正文和工作簿均保留未经校正p与校正q；95%区间未作多重性调整。')
p('Q22同一受访者的五维差距采用Friedman检验，并报告Kendall W。10个维度对的均值差采用保留零差与并列的精确符号翻转置换检验，10对共同BH校正；均值差区间为配对t近似，仅辅助描述。此方法把五级评分视为近似等距，并要求零假设下差值可交换符号，解释时保留这一假设。')
p('上述区间及检验是模型条件下的探索性描述。因抽样方式未证实为概率抽样、机构可能重复、医院聚类无法识别，它们不能修正代表性偏差，不能作为全国推断或因果证明。统计不显著也不等同于两组相同。')
page();h('三 受访者结构与机构培养现状')
table(['变量','主要结果','含义与限制'],[['医院类别','三级145/162（89.5%）；二级14/162（8.6%）；其他3/162','按原题编码，不将其他填报细节重新识别为医院'],['职务','院级领导6，总会计师14，部门正职41，副职30，其他71','管理者定义为Q4编码1至4，共91'],['年龄与学历','31至40岁99份；硕士88、本科70、博士3、大专及以下1','不能精确重建36至55岁年龄段'],['职称','正高级25、副高级50、中级83、初级及以下1、未评聘3','高级合计75/162（46.3%）'],['部门与专业','财务或审计部门109；财审专业142','部门归属与教育专业不可混用'],['地区构成','江苏38、河南33，合计71/162（43.8%）','统一省市后缀；不公开城市与个人组合']],[.18,.46,.36])
p('样本以具有较高学历的财审背景在职人员为主，适合识别这部分群体对业财融合培养的评价。与基层、初入职、非财审背景人员的需求差异尚需进一步补样。不能将受访者个人结构当作其所在医院全体经济管理人员的结构。')
rows=Q['10']['rows'];bar('institutions',[x['项目'] for x in rows],[100*x['是比例'] for x in rows],'岗位与机构设置的报告比例','来源 Q10；每项分母162；1=是、2=否')
h('培养制度与资源投入',2)
p('32/162份（19.8%）回答有制度且落实到位，49份（30.2%）有制度但落实不足，81份（50.0%）无系统制度安排。后两类共130份，需按其原始含义区分，不能全部称为无制度。')
p('年人均培训学时在20学时以下与20至40学时两个档次的合计103份（63.6%）；年人均经费在1000元以下与1000至3000元档次合计110份（67.9%）。档位边界来自原题，不能用组中值反推精确平均学时或平均经费。人员配置严重不足或相对不足82份（50.6%），提示课程安排应与学习时间和人员替补安排结合。')
page();h('四 复合能力差距与人才需求')
rows=Q['22']['rows'];bar('gaps',[x['子项'].split(':')[0] for x in rows],[100*x['4至5分比例'] for x in rows],'五维能力高差距比例','来源 Q22；4至5分表示差距较大；每项分母162')
table(['维度','均值','中位数','高差距 n/N','Wilson 95%区间'],[[x['子项'].split(':')[0],f"{x['均值']:.2f}",f"{x['中位数']:.0f}",f"{x['4至5分人数']}/162",f"{pct(x['Wilson95下限'])} 至 {pct(x['Wilson95上限'])}"] for x in rows],[.33,.12,.12,.18,.25])
p(f"五维整体分布存在差异，Friedman统计量为{R['friedman']['统计量']:.2f}，p={pf(R['friedman']['p'])}，Kendall W={R['friedman']['Kendall W']:.3f}。效应大小较有限，不能因p值很小就认为差距悬殊。业务与数据均应纳入课程优先议题；两者均值差0.173分，精确置换p=0.05049，10对BH q=0.07214，未形成明确区分证据。")
rows=sorted(Q['23']['rows'],key=lambda x:-x['前三入选人数']);bar('talent',[x['选项'] for x in rows],[100*x['前三入选率'] for x in rows],'未来三年人才需求排序','来源 Q23；同时呈现前三入选率与首选率；每项分母162',[100*x['首选率'] for x in rows])
p('按前三入选，运营管理133份、数据分析120份、综合管理89份位列前三；成本与预算83份排第四。按首选，运营67份、综合34份、成本与预算29份位列前三。两套排名回答不同问题，不能交换。医保人才前三42份（25.9%），而医保课程高必要性149份（92.0%）；前者是有限名额下的相对人才需求排序，后者是绝对课程必要性，不能据此认定医保重要性被低估。')
page();h('五 培养方式及课程供需')
rows=sorted(Q['26']['rows'],key=lambda x:-x['4至5分人数']);bar('courses',[x['子项'] for x in rows],[100*x['4至5分比例'] for x in rows],'各课程模块的高必要性比例','来源 Q26；4至5分；每项分母162')
p('多项课程均呈现高必要性，说明培养需要兼顾业务理解、管理协同和数据方法。高认可可能受共同方法偏差或倾向性回答影响，单凭必要性打分难以决定课时分配；应结合岗位任务、现有基础与实践成果进行选择。')
table(['同一答卷的数智需求与供给','报告已有数据工具培训','未勾选现有培训','合计'],[['数智高需求','47','109','156'],['非高需求','2','4','6'],['合计','49','113','162']],[.46,.18,.18,.18])
p('109份“高需求且未勾选供给”是可优先跟进的需求信号。Q26涉及数智化运营与数据分析课程，Q17涉及信息化与数据工具，概念并不完全一致；现有培训还可能存在记忆遗漏。因此建议在课程试点前进行简短课程清单核对，而非直接认定供给空白。')
page();h('培养方式偏好与可落地组合')
rows=sorted(Q['25']['rows'],key=lambda x:-x['前三入选人数']);bar('methods',[x['选项'] for x in rows],[100*x['前三入选率'] for x in rows],'培养方式的前三入选率与首选率','来源 Q25；每项分母162',[100*x['首选率'] for x in rows])
p('前三入选最普遍的方式是跟岗125份（77.2%）、项目95份（58.6%）和案例90份（55.6%）。双导师62份（38.3%）虽不是前三覆盖的前三项，但首选33份，仅次于跟岗65份，显示有一部分受访者将持续导师支持置于较高优先级。不能仅依据前三覆盖率否定导师制价值。')
p('已有跟岗或轮岗培训方式70份（43.2%）；偏好跟岗且未报告现有相应方式72份（44.4%）。另一方面，双导师已实施仅7份，另有12份希望一年内启动、91份有意愿但条件暂不具备、52份暂无意愿。导师安排需要明确工作量、激励、业务导师与财务导师职责，而不能只列入课程方案。')
p('合理培养周期以3至5年103份（63.6%）为主。建议将短期实训嵌入多阶段发展安排，而非把一次培训认定为复合能力形成。Q24和Q40对分层与全链条路径的完整认可分布见附录，尚不能证明任一阶段安排具有因果效果。')
page();h('六 组织保障与成果转化')
rows=sorted(Q['19']['rows'],key=lambda x:-x['选择人数']);bar('problems',[x['选项'] for x in rows],[100*x['选择率'] for x in rows],'现有培训的主要问题','来源 Q19；最多4项；分母162')
p('短期集中为主、缺乏跟踪管理108份（66.7%），分层分类不够、针对性不强82份（50.6%）。这提示改善重点不仅是增加课程，还包括明确学习前目标、过程辅导、培训后项目成果与持续追踪。')
rows=sorted(Q['46']['rows'],key=lambda x:-x['选择人数']);bar('barriers',[x['选项'] for x in rows],[100*x['选择率'] for x in rows],'成果转化落地的主要障碍','来源 Q46；最多3项；分母162')
p('实践锻炼与项目历练机会不足126份（77.8%），考核激励与结果运用机制不完善96份（59.3%）。实践基地、真实项目池与评价机制应同步设计，避免只有培训而没有可执行任务，也避免把培训完成率当作管理改善成效。')
rows=sorted(Q['38']['rows'],key=lambda x:-x['前三入选人数']);table(['主管部门政策支持','首选人数','前三人数','前三率'],[[x['选项'],x['第1名'],x['前三入选人数'],pct(x['前三入选率'])] for x in rows],[.53,.15,.15,.17])
p('Q28有3份同时选择尚无合作与具体合作形式，标为潜在矛盾但主分析保留；Q30有7份同时选择尚无系统评估与某具体评价方式，可能存在零散评价但尚未形成体系，不能改写为完全没有任何评价。')
p('政策前三需求以纳入卫生健康人才发展规划120份（74.1%）和设立专项培养经费106份（65.4%）较突出。结合Q32至Q35对组织机制、激励与职业通道的评分，建议政策试点把职责、经费、实践任务及职业发展衔接成完整流程，并记录实际执行程度。')
page();h('七 探索性比较与不确定性')
h('制度落实与评估的关联',2)
p('制度落实到位者32份中，选择“尚无系统评估”的有9份（28.1%）；其他回答130份中有76份（58.5%）。两组比例差为−30.3个百分点，未作多重性调整的Newcombe 95%区间为−45.3至−11.1个百分点；双侧Fisher p=0.002773，制度落实3项家族BH q=0.008318。')
p('这一结果说明制度落实与评估安排同时出现，但横截面问卷无法判断时间先后、共同治理能力或机构资源的作用。其他130份由49份“有制度但落实不足”和81份“无系统制度安排”组成；不得把组间差异写成制度的净因果效果。')
rows=[x for x in R['cross_tabs'] if x['检验家族']=='制度落实3项'];table(['结局','落实组','其他回答','比例差','p','BH q'],[[x['结局'],f"{x['组1事件']}/{x['组1分母']}",f"{x['组0事件']}/{x['组0分母']}",f"{100*x['比例差']:.1f}个百分点",pf(x['Fisher双侧p']),pf(x['BH q'])] for x in rows],[.29,.14,.14,.18,.12,.13])
h('医院类别与职务的探索性分组',2)
hm=[x for x in R['cross_tabs'] if x['检验家族']=='医院类别12项'];rm=[x for x in R['cross_tabs'] if x['检验家族']=='职务分组12项']
p(f"医院类别比较限定原题三级类别145份与二级类别14份，其他3份不进入该比较。本次列明的12个探索性结局中，最低BH q={min(x['BH q'] for x in hm):.4f}。小组样本不足、统计功效有限，不足以据此制定已经验证的医院层级最优方案。职务比较为Q4编码1至4共91份与其他71份；其他类别含多种岗位经历，不能称为统一的非管理专业群体。")
p('本次分组表是探索性比较，不构成回归调整后的效应。医院类别、地区、职务、专业与机构资源可能同时影响回答。应在下一轮采样时明确医院标识和抽样框，预先选定少量关键终点，按医院聚类评估。完整33项比较见附录与工作簿。')
page();h('八 人员结构选答的专门核验')
p('Q11的原题范围是总会计师、财务（不含窗口收费人员）、审计、运营、合规、医保、绩效等部门人员。不能默认填报值代表全院职工，也不能认定所有受访者对经济管理范围有相同理解。Q11总人数字段有效98份、合计12573、最大5300；如此大的单条计数需要回访核实，但大值本身不证明错误，本次主样本不予删除。')
table(['题目','任一非空','任一有效数值','全部字段有效','整题空白'],[['Q11 15字段',102,100,78,60],['Q12 6字段',100,98,81,62]],[.30,.175,.175,.175,.175])
p('原始空白包含字符串“(空)”，另有“不清楚”“不知道”等非数值。有效数字定义为非负整数；零是有效填报，不按空白处理。总人数有效98份与其余64份的可用性比较，分组口径不同于“任一作答102与空白60”，不得混称。')
table(['总人数字段情景','记录数','计数合计'],[[x['口径'],x['答卷数'],f"{x['填报计数合计']:,.0f}"] for x in R['headcount_quality'] if '最大' in x['口径']],[.60,.18,.22])
p('以上均为未按医院去重的记录计数之和，不是真实独立人员数。最大记录移除后合计变化显著，表明用一个汇总总量描述行业人员规模不稳妥。')
h('类别加总只用于假设性敏感性',2)
p('学历、职称、专业分项是否互斥且穷尽未获证实。分项和等于总人数是一种核对条件，不能被当作无误填写的认证。不同结构的可用记录不同，不能把各列全部有效值合计拼成同一总体画像。')
selected=[x for x in R['headcount_sensitivity'] if x['敏感性情景']!='分项完整' and ((x['结构']=='学历' and '本科' in x['项目']) or (x['结构']=='专业' and '财会' in x['项目']))]
table(['结构与情景','记录数','项目计数/同记录总数','计数比'],[[x['结构']+' '+('本科' if x['结构']=='学历' else '财会审计类')+' '+x['敏感性情景'],x['有效答卷数'],f"{x['项目填报计数']:.0f}/{x['同记录总人数计数']:.0f}",pct(x['计数比'])] for x in selected],[.48,.12,.25,.15])
p('IQR高值上界由Q11总人数有效记录计算，为102；超过该阈值仅作为敏感性排除条件，不认定为错误。教育和专业占比对大额记录的敏感程度不同，专业计数比从38.8%到70.8%的变化尤其提示口径风险。')
h('Q12的资格计数不可相加为持证人数',2)
p('Q12明确要求同一人持有多项资格分别计入。CPA字段有效87份、计数和91；CMA字段有效82份、计数和32。各字段来自不同可用记录，资格可能重叠，不能把两者或全部资格合计解释为独立持证人数。旧建议中CPA45和管理会计14未在相同口径下重现，应以原始题目和明确分母重做，而不是强制对齐旧数。')
page();h('九 稳健性与旧结论检查')
p('少于300秒的答卷2份，59个量表子项全部同分的答卷5份，合并标记6份。此类特征仅提示需要复核，不是无效认定。主分析保留全部162份，敏感性分析排除这6份后使用156份。')
table(['情景','数智高需求','跟岗前三','缺乏跟踪','数据高差距'],[[sc]+[f"{x['人数']}/{x['分母']}（{pct(x['比例'])}）" for label in ['数智课程高需求','跟岗进入前三','缺乏培训后跟踪','数据能力高差距'] for x in R['sensitivity'] if x['情景']==sc and x['指标']==label] for sc in ['全样本','剔除快速或全量表同分','去除江苏与河南']],[.28,.18,.18,.18,.18])
p('去除江苏与河南后为91份，数据高差距25/91（27.5%），低于全样本35.2%。因此只能说若干核心需求方向在快速或同分标记敏感性中相近，不能笼统宣称全部结论对地区构成都稳健。地区排除同时改变样本结构，也不能解释为地区本身的因果影响。')
table(['待核验说法','本次证据','结论'],[['本科主导、中级及以下超过85%','个人硕士54.3%；高级46.3%','不适用于受访者个人结构'],['管理者或领导人数混用','管理者91；院领导及总会计师20','必须明确Q4定义'],['业务差距显著高于数据差距','精确p=.05049；10对BH q=.07214','差异不确定'],['未来需求前三为运营、数据、成本','综合89高于成本83','第三位应为综合'],['医保排名低说明不重要','人才前三25.9%；课程高必要92.0%','两题不可作该推论'],['1140、1144、1145为可靠总人数','Q11有效98、计数12573，未医院去重','旧总数未重现且口径不明'],['CPA45、管理会计14','CPA计数91；CMA计数32','相应口径未重现'],['按医院层级已证明最优策略不同','二级仅14份，探索性比较有限','证据不足']],[.33,.43,.24])
h('开放意见的编码解释',2)
p('Q47有12份实质意见。本次采用公开可复现关键词规则并人工检查，多标签主题为治理与组织支持7、职业发展与公平激励3、实践应用3、经费或学习实践机会2、协同与案例共享1。此前汇总的治理制度为6，本版将领导认可等组织支持纳入更宽的治理与组织支持主题，不能把主题计数变化当作受访者新增意见。主题分母为12，原文及序号不公开。')
p('旧汇总中的业务与数据p约0.0502来自随机模拟。本版使用精确符号翻转p=0.0504946，并对完整10对维度进行BH校正，因此q与此前较小的三对比较家族不完全相同。方法变化不改变“业务与数据之间尚不明确”的判断。')
page();h('十 可执行建议与后续研究')
h('第一阶段  核实需求与确定试点',2)
p('由医院培养归口部门会同财务、运营、医保、临床与信息部门，在现有培训目录基础上核对数据工具、业务流程与真实管理项目供给。以问卷显示的数智、业务和运营需求为线索，选取2至3个能获得数据和业务配合的项目，例如病种成本与运营分析、预算执行偏差分析或医保精细化管理。具体项目数量为实施建议，不是调查测量结果。')
h('第二阶段  设计分层实践任务',2)
p('新入职人员以流程理解、制度规范和数据基础为主；业务骨干承担分析与改进任务；中层侧重跨部门协同、项目治理与带教；领军人才侧重战略和系统治理。该分层来自原题及管理设计逻辑，需根据岗位实测能力调整，不应仅凭职称或年龄分配学习机会。采用跟岗、真实项目、案例复盘与双导师支持的组合，明确每项任务的业务问题、交付物和评价人。')
h('第三阶段  跟踪评估与结果运用',2)
table(['环节','建议记录的可观察指标','解释要求'],[['学习前','岗位任务清单、基线能力测评、项目基线','不把自评需求当作客观能力'],['学习中','导师反馈、参与时间、阶段成果','跟踪过程，避免只记出勤'],['学习后','案例与分析报告质量、应用情况','培训完成不等于成果落地'],['后续追踪','同口径业务指标、使用部门反馈、持续应用','注明同时期改革和资源变化'],['激励运用','公开评价标准、岗位与成长机会衔接','避免仅以证书或短期分数定优劣']],[.18,.46,.36])
p('建议先进行小规模分阶段试点，再评价是否扩展。若资源允许，可采用分批上线的比较设计，预先确定主要终点、追踪时间、缺失处理和分析计划。避免事后挑选显著结果作为有效性证明。')
h('下一轮调查的必要改进',2)
p('建立非公开、可去重的医院标识；补充抽样框、邀请范围和响应率；扩大二级与基层覆盖；对Q11明确总人数范围、分项是否互斥及类别加总规则；对Q12区分资格人次与独立人数；在Q41与Q42之间加入跳题或“从未开展”选项；采集现有课程名称、实际培训投入和项目成果，以缩小当前“主观偏好”与“实际效果”之间的证据距离。')
page();h('附录A 47题完整统计')
p('本附录按原题顺序列出全部题目。除Q11、Q12和Q47专门分母外，表中人数均为答卷数。量表分布依次为1至5分人数，高分为4至5分；Q22与Q35含义不同，必须连同题目锚点阅读。多选和排序选项保留原始术语，其他项的自由填写内容不公开。',True)
for qi in range(1,48):
    q=Q[str(qi)];h(f'Q{qi} '+q['title'],2);rr=q['rows'];kind=q['type']
    if kind in ['单选','地域']:
        table(['选项','人数','分母','比例'],[[x['选项'],x['人数'],x['分母'],pct(x['比例'])] for x in rr],[.55,.15,.15,.15])
    elif kind=='是非矩阵':
        table(['项目','是','否','分母','是比例'],[[x['项目'],x['是'],x['否'],x['分母'],pct(x['是比例'])] for x in rr],[.5,.12,.12,.12,.14])
    elif kind=='多选':
        table(['选项','选择人数','分母','选择率'],[[x['选项'],x['选择人数'],x['分母'],pct(x['选择率'])] for x in rr],[.55,.15,.15,.15])
    elif kind=='前三排序':
        table(['选项','第1','第2','第3','前三人数','首选率','前三率'],[[x['选项'],x['第1名'],x['第2名'],x['第3名'],x['前三入选人数'],pct(x['首选率']),pct(x['前三入选率'])] for x in rr],[.39,.08,.08,.08,.12,.12,.13])
    elif kind=='五级量表':
        table(['子项','1至5分人数','均值±标准差','4至5分 n/N','高分比例'],[[x['子项'],' / '.join(str(x[f'{k}分']) for k in range(1,6)),f"{x['均值']:.2f}±{x['标准差']:.2f}",f"{x['4至5分人数']}/{x['有效数']}",pct(x['4至5分比例'])] for x in rr],[.42,.20,.14,.13,.11])
    elif kind=='选填人数':
        def short(s):return re.sub(r'^\(\d+\)人[; 、]*','',s).replace('___','').replace('人  （如不清楚，可不填写）','').replace('人 （如不清楚，可不填写）','')
        table(['项目','有效数','空白','非空无效','计数和','中位数','最大值'],[[('在岗总人数' if qi==11 and ix==0 else '正高级专业技术资格' if qi==12 and ix==0 else short(x['项目'])),x['有效填报数'],x['空白数'],x['非空无效数'],f"{x['计数合计']:.0f}",f"{x['中位数']:.1f}",f"{x['最大值']:.0f}"] for ix,x in enumerate(rr)],[.39,.10,.10,.12,.10,.10,.09])
    else:
        table(['主题','涉及意见数','实质意见分母','意见内比例'],[[x['主题'],x['涉及意见数'],x['实质意见分母'],pct(x['意见内比例'])] for x in rr],[.43,.19,.20,.18])
    p(q['note'],True);p('数据追溯  '+q['source'],True)
page();h('附录B 完整比较与追溯说明')
h('Q22全部配对比较',2)
table(['维度对','均值差','95%区间','精确p','10对BH q'],[[x['维度1'].split(':')[0]+' / '+x['维度2'].split(':')[0],f"{x['均值差']:.3f}",f"{x['均值差95下限']:.3f} 至 {x['均值差95上限']:.3f}",pf(x['精确符号置换p']),pf(x['BH q'])] for x in R['pairwise']],[.35,.13,.24,.14,.14])
p('差值方向为表内第一维度减第二维度；区间未作多重比较调整。区间与精确检验采用不同方法，在临界值附近可能产生轻微边界差异，应以完整方法与效应大小解释。',True)
for fam in ['医院类别12项','职务分组12项','制度落实3项','Q11可用性6项']:
    h(fam,2);rows=[x for x in R['cross_tabs'] if x['检验家族']==fam];p('比较方向  '+rows[0]['组1']+' 减 '+rows[0]['组0'],True)
    table(['结局','组1 n/N','组0 n/N','差值百分点','p','BH q'],[[x['结局'],f"{x['组1事件']}/{x['组1分母']}",f"{x['组0事件']}/{x['组0分母']}",f"{100*x['比例差']:.1f}",pf(x['Fisher双侧p']),pf(x['BH q'])] for x in rows],[.31,.16,.16,.15,.11,.11])
h('质量核查与复现路径',2)
table(['检查','结果'],[[x['项目'],x['结果']] for x in R['quality']],[.32,.68])
p('公开附件包含聚合表、统计工作簿、分析脚本、图表及生成报告脚本。数据字典标注每个问题及子项在数值版Sheet1的列范围；Excel第2至163行为162份答卷。原始输入不包含在复现包中，需由数据持有人自行在本地指定。')
p('复现主入口：analyze.py读取两个原始导出，输出aggregate_tables.json和CSV；build_report.py根据聚合JSON生成Word与PDF。完整重算需要Python、pandas、numpy、scipy、openpyxl、python-docx、reportlab、matplotlib及中文字体。工作簿由单独JS生成器从相同聚合JSON生成。')
p('已完成两版本32562格交叉核验，并由独立脚本直接解析XLSX的XML验证相同字段与关键计数。本报告所有公开计数均从本版脚本输出；参考模板仅作结构参考。公开版不包含输入文件、逐人数据、实际IP、时间戳、原始序号或可识别开放原文。')

def footer_pdf(canvas,dd):
    canvas.saveState();canvas.setFont('STSong-Light',8);canvas.setFillColor(colors.HexColor('#596674'))
    canvas.drawString(57,27,'卫生健康经济管理人才培养调查  |  公开汇总版')
    canvas.drawRightString(A4[0]-57,27,str(dd.page));canvas.restoreState()
pdfpath=OUT/'卫生健康经济管理人才培养调查完整报告.pdf';docxpath=OUT/'卫生健康经济管理人才培养调查完整报告.docx'
pdf=SimpleDocTemplate(str(pdfpath),pagesize=A4,rightMargin=57,leftMargin=57,topMargin=47,bottomMargin=45,title='卫生健康经济管理人才培养调查完整报告',author='调查分析',pageCompression=1)
pdf.build(story,onFirstPage=footer_pdf,onLaterPages=footer_pdf)
doc.save(docxpath);(ROOT/'work/report_text.txt').write_text('\n\n'.join(plain),encoding='utf-8')
print(json.dumps({'pdf':str(pdfpath),'docx':str(docxpath),'paragraphs':len(plain)},ensure_ascii=False))
