#!/usr/bin/env python3
"""Create the public, aggregate-only Chinese report from analyze.py output."""
import json, re, sys, math, textwrap
from pathlib import Path
from xml.sax.saxutils import escape
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_CENTER
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,Image,KeepTogether
from reportlab.lib.pagesizes import A4
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT=Path(__file__).resolve().parent
DATA=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'work/aggregate_tables.json'
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else ROOT/'deliverables'
OUT.mkdir(parents=True,exist_ok=True);FIG=ROOT/'work/figures';FIG.mkdir(parents=True,exist_ok=True)
R=json.loads(DATA.read_text());Q=R['question_tables'];N=R['metadata']['N']
pdfmetrics.registerFont(UnicodeCIDFont('STSong-Light'))
font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
plt.rcParams.update({'font.family':'Noto Sans CJK JP','axes.unicode_minus':False,'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.edgecolor':'#CAD3DC','savefig.facecolor':'white'})
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='CN',fontName='STSong-Light',fontSize=10.5,leading=17,spaceAfter=7,wordWrap='CJK'))
styles.add(ParagraphStyle(name='SmallCN',parent=styles['CN'],fontSize=8.5,leading=12,spaceAfter=5,textColor=colors.HexColor('#525E6B')))
styles.add(ParagraphStyle(name='CellCN',parent=styles['CN'],fontSize=8.5,leading=12,spaceAfter=0))
styles.add(ParagraphStyle(name='HeadCellCN',parent=styles['CellCN'],textColor=colors.white))
styles.add(ParagraphStyle(name='TitleCN',parent=styles['CN'],fontSize=26,leading=37,spaceAfter=18))
styles.add(ParagraphStyle(name='H1CN',parent=styles['CN'],fontSize=17,leading=24,spaceBefore=14,spaceAfter=10,keepWithNext=True))
styles.add(ParagraphStyle(name='H2CN',parent=styles['CN'],fontSize=12.5,leading=19,spaceBefore=12,spaceAfter=7,keepWithNext=True))
doc=Document();sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11);sec.top_margin=Inches(.72);sec.bottom_margin=Inches(.65);sec.left_margin=Inches(.75);sec.right_margin=Inches(.75)
for name in ['Normal','Title','Heading 1','Heading 2','Heading 3','Caption']:
    s=doc.styles[name];s.font.name='Noto Sans CJK SC';s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');s.font.color.rgb=RGBColor(0,0,0)
doc.styles['Normal'].font.size=Pt(10);doc.styles['Normal'].paragraph_format.line_spacing=1.15;doc.styles['Normal'].paragraph_format.space_after=Pt(5)
doc.styles['Title'].font.size=Pt(25);doc.styles['Heading 1'].font.size=Pt(17);doc.styles['Heading 2'].font.size=Pt(12.5)
for sty in doc.styles:
    if sty._element.pPr is not None:
        for border in list(sty._element.pPr.findall(qn('w:pBdr'))):sty._element.pPr.remove(border)
doc.styles['Caption'].font.bold=False;doc.styles['Caption'].font.size=Pt(8.5)
header=sec.header.paragraphs[0];header.text='卫生健康经济管理人才培养调查';header.style='Caption'
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
footer.add_run('汇总公开版  |  ')
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
story=[];plain=[];next_doc_page=False
def p(txt,small=False,keep=False):
    txt=str(txt).replace('−','-');st=ParagraphStyle('keep',parent=styles['SmallCN' if small else 'CN'],keepWithNext=keep);story.append(Paragraph(escape(txt).replace('\n','<br/>'),st));dp=doc.add_paragraph(txt,style='Caption' if small else 'Normal');dp.paragraph_format.keep_with_next=keep;plain.append(txt)
def h(txt,level=1):
    global next_doc_page
    story.append(Paragraph(escape(txt),styles[f'H{level}CN']));hp=doc.add_heading(txt,level=level);plain.append(txt)
    if next_doc_page: hp.paragraph_format.page_break_before=True;next_doc_page=False
def page():
    global next_doc_page
    story.append(PageBreak());next_doc_page=True
def table(headers,rows,widths=None):
    if not rows:return
    widths=widths or [1/len(headers)]*len(headers)
    if sum(widths)>1.1:widths=[x/sum(widths) for x in widths]
    formatted=[[str(x) if x is not None else '—' for x in row] for row in rows]
    cells=[[Paragraph(escape(str(x)),styles['HeadCellCN']) for x in headers]]+[[Paragraph(escape(x),styles['CellCN']) for x in row] for row in formatted]
    tb=Table(cells,colWidths=[481*x for x in widths],repeatRows=1,hAlign='LEFT')
    tb.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#193A54')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('GRID',(0,0),(-1,-1),.35,colors.HexColor('#D9D9D9')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F1F5F8')])]))
    story.extend([tb,Spacer(1,9)])
    tbw=doc.add_table(rows=1,cols=len(headers));tbw.autofit=False
    for i,col in enumerate(tbw.columns):col.width=Inches(7*widths[i])
    for i,(cell,name) in enumerate(zip(tbw.rows[0].cells,headers)):
        cell.text=str(name);cell.width=Inches(7*widths[i]);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'193A54');cell._tc.get_or_add_tcPr().append(sh)
        for rr in cell.paragraphs[0].runs:rr.font.color.rgb=RGBColor(255,255,255);rr.font.bold=True
    repeat=OxmlElement('w:tblHeader');tbw.rows[0]._tr.get_or_add_trPr().append(repeat)
    for ri,row in enumerate(formatted):
        cs=tbw.add_row().cells
        for i,(cell,value) in enumerate(zip(cs,row)):
            cell.text=value;cell.width=Inches(7*widths[i])
            if ri%2==1:
                sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'F1F5F8');cell._tc.get_or_add_tcPr().append(sh)
    for row in tbw.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                para.paragraph_format.space_after=Pt(3);para.paragraph_format.space_before=Pt(3)
                for rr in para.runs:rr.font.size=Pt(8.5)
            pr=cell._tc.get_or_add_tcPr();borders=OxmlElement('w:tcBorders')
            for edge in ['top','left','bottom','right']:
                e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
            pr.append(borders)
    doc.add_paragraph('');plain.append(' | '.join(headers));plain.extend(' | '.join(x) for x in formatted)
def pct(x):return f'{100*x:.1f}%'
def pf(x):return f'{x:.3g}' if x<.001 else f'{x:.4f}'
def bar(name,labels,values,title,source,second=None):
    height=max(2.65,0.33*len(labels)+.65);fig,ax=plt.subplots(figsize=(7.6,height));yy=list(range(len(labels)))
    if second is None:
        ax.barh(yy,values,color='#245A7A',height=.62)
        for y,v in zip(yy,values):ax.text(v+1,y,f'{v:.1f}%',va='center',fontsize=9)
    else:
        ax.barh([y-.18 for y in yy],values,height=.32,color='#245A7A',label='前三入选率')
        ax.barh([y+.18 for y in yy],second,height=.32,color='#A8C2D3',label='首选率');ax.legend(loc='lower right',frameon=False)
    ax.set_yticks(yy,[textwrap.fill(x,18) for x in labels]);ax.invert_yaxis();ax.set_xlim(0,112);ax.set_xticks([0,20,40,60,80,100],[f'{x}%' for x in [0,20,40,60,80,100]]);ax.grid(axis='x',alpha=.17);ax.set_axisbelow(True);ax.tick_params(axis='y',length=0);fig.tight_layout()
    path=FIG/f'{name}.png';fig.savefig(path,dpi=180,bbox_inches='tight');plt.close(fig)
    h(title,2);img=Image(str(path),width=470,height=470*height/7.6);story.append(img);doc.add_picture(str(path),width=Inches(6.3));p(source,True)

story.append(Spacer(1,66));story.append(Paragraph('业财融合视域下<br/>卫生健康经济管理人才培养<br/>调查分析报告',styles['TitleCN']))
doc.add_paragraph('业财融合视域下\n卫生健康经济管理人才培养\n调查分析报告',style='Title')
p('基于162份问卷的人才需求与培养路径分析')
p('本报告围绕培养对象、能力短板、课程需求、实践方式和组织保障展开，为卫生健康经济管理人才培养项目提供决策参考。')
p('调查呈现出清晰的培养方向：将业务理解与数据分析共同作为重点，以运营管理项目连接课程与岗位实践，并把导师指导、过程跟踪和成果运用纳入日常管理。')
p('分析日期  2026年10月17日')
p('汇总报告  管理汇报修订版',True)
page();h('阅读导航')
for a in ['一 主要发现与管理启示','二 调查对象与阅读口径','三 培养现状与资源配置','四 能力短板与人才需求','五 课程安排与实践方式','六 组织保障与职业发展','七 分组结果与培养安排','八 项目实施建议','附录A 各题统计结果','附录B 统计方法与比较结果']:p(a)
p('正文按“发现了什么—意味着什么—可以怎样做”展开。各题详细数据及统计检验结果列于附录，配套Excel提供完整计算与核验记录。',True)
page();h('一 主要发现与管理启示')
h('业务理解与数据分析应共同成为培养重点',2)
p('受访者认为，业务能力和数据能力是较突出的短板。66人认为现有队伍的业务能力差距较大，占40.7%；57人认为队伍的数据能力差距较大，占35.2%；财务能力对应比例为25.9%。这说明培养内容需要在财务专业基础上，进一步加强医疗业务理解、运营分析和数据应用。')
p('业务与数据两项评分比较接近，目前还不足以判断哪一项明显更急迫。课程设计宜将两者结合：通过一个实际业务问题，训练流程理解、数据分析和管理建议形成的完整过程。')
h('数智课程需求强烈 现有培训仍有拓展空间',2)
p('156人认为数智化运营与数据分析课程较有必要，占96.3%；49人报告已有信息化与数据工具培训，占30.2%。其中，109人既表达了较高的数智课程需求，又未勾选现有数据工具培训，占全体受访者的67.3%。这部分需求值得在课程安排中优先关注，并结合实际课程目录确定补充内容。')
h('加强实践机会与持续指导',2)
p('跟岗实训、项目制学习和真实案例学习获得较多选择。与此同时，108人指出现有培训缺乏持续跟踪，126人指出实践锻炼和项目历练机会不足。培养项目应把课程学习与真实任务衔接起来，使学员在学习之后有机会应用、有导师反馈、有成果评价。')
table(['培养重点','调查发现','管理安排建议'],[
['人才方向','未来需求前三入选人数：运营133、数据120、综合89','围绕运营问题配置业务、数据和综合协调课程'],
['实践方式','跟岗125、项目95、案例90人列入前三','建设跟岗岗位和项目清单，配套案例复盘'],
['过程管理','108人反映缺乏跟踪；82人反映分层不足','明确阶段目标，按能力基础安排任务'],
['成果运用','126人反映实践机会不足；96人反映激励与结果运用不完善','提供实际应用场景，将成果纳入评价'],
['制度落实','落实到位组报告无系统评估的比例为28.1%，其他组为58.5%','同步建设培养制度与评价工具']],[.18,.43,.39])
p('本报告据此提出课程与管理改进方向。实施时可先安排小规模试点，以项目成果质量和实际应用情况检验成效，再逐步扩大。')
page();h('二 调查对象与阅读口径')
p('本次分析包括162名受访者的47题问卷。两个Excel文件是同一批答卷的数值版与文本版，已逐项对照核验，合并用于分析。正文中的人数和比例以受访者为单位，反映本次参与调查人群的意见与情况。')
table(['特征','人数与比例','培养设计启示'],[
['医院类别','三级145人（89.5%）；二级14人（8.6%）；其他3人','本次需求主要体现三级类别受访者的工作背景'],
['管理岗位','院级领导6人、总会计师14人、部门正职41人、副职30人，共91人','兼顾管理决策、跨部门协同与骨干业务能力'],
['年龄','31至40岁99人（61.1%）','围绕在职发展和能力进阶安排学习任务'],
['学历','硕士88人（54.3%），本科70人（43.2%）','加强知识应用和综合分析训练'],
['职称','正高级25人、副高级50人、中级83人；高级合计46.3%','将培养层次与实际承担任务相结合'],
['专业背景','财务审计类142人（87.7%）','加强医疗业务、医保和信息技术的跨专业学习'],
['部门归属','财务或审计部门109人（67.3%）','拓展财务与临床、运营、信息部门的协作场景']],[.17,.46,.37])
p('受访者整体具有较好的学历与财审专业基础。人才培养可以更多转向“如何把专业知识用于医疗业务和运营管理”，通过跨部门项目把既有经验与新的数据方法结合起来。')
h('数据怎样阅读',2)
p('单选题比例表示选择该项的人数占比。多选题允许一人选择多项，因此各项比例相加可以超过100%。排序题同时报告“列入前三”和“列为首选”：前者说明需求覆盖面，后者说明最优先考虑的方向。')
p('五级评分中，4至5分归为较高评价。不同题目中的高分含义随题意变化：能力差距题高分表示短板更明显，课程必要性题高分表示需求更强，职业通道题高分表示更畅通。第11和12题按实际填报记录分别统计，明细见附录。')
page();h('三 培养现状与资源配置')
rows=Q['10']['rows'];bar('institutions',[x['项目'] for x in rows],[100*x['是比例'] for x in rows],'岗位与机构设置情况','来源 Q10；每项162人，比例为回答“是”的受访者占比')
h('制度建设需要进一步落实到日常运行',2)
p('32人回答所在机构培养制度落实到位，占19.8%；49人回答已有制度但落实不足，占30.2%；81人回答尚无系统制度安排，占50.0%。管理改进可以分两步推进：先明确培养责任、目标与年度安排，再通过任务分配、过程记录和成果评价推动执行。')
p('在第39题的人才培养组织管理评价中，91人报告已明确人才培养归口管理部门，69人报告已制定中长期培养规划，51人报告已建立培养档案与学时台账。建议将归口管理与具体任务连接起来，由责任部门统筹课程、导师、实践岗位及评价记录。')
h('把有限学习时间优先用于岗位问题',2)
p('103人的回答落在年人均培训20学时以下或20至40学时两个档次，占63.6%；110人的回答落在年人均经费1000元以下或1000至3000元两个档次，占67.9%。另有82人反映人员配置严重不足或相对不足，占50.6%。课程安排应考虑工作与学习的衔接，采用分阶段任务、集中实训和岗位应用相结合的方式。')
p('148人报告培养经费来自单位预算，占91.4%；62人报告有主管部门专项经费支持，占38.3%。单位预算是本次填报中最常见的经费来源，建议将导师指导、项目实践和后续评价一并纳入预算安排。')
h('现有管理任务可以直接转化为教学项目',2)
p('在已开展的业财融合举措中，全面预算管理127人、公立医院绩效考核121人、DRG/DIP支付方式改革109人、全成本核算102人、内部控制与财会监督101人。可围绕这些工作设计项目，让学员使用实际业务流程与数据完成分析，提升学习内容与日常任务的关联。')
page();h('四 能力短板与人才需求')
rows=Q['22']['rows'];bar('gaps',[x['子项'].split(':')[0] for x in rows],[100*x['4至5分比例'] for x in rows],'认为现有队伍各类能力差距较大的受访者比例','来源 Q22；4至5分表示差距较大；每项162人')
table(['能力维度','平均评分','评分中位数','评价差距较大人数','占比'],[[x['子项'].split(':')[0],f"{x['均值']:.2f}",f"{x['中位数']:.0f}",x['4至5分人数'],pct(x['4至5分比例'])] for x in rows],[.38,.16,.16,.16,.14])
p('五类能力评分存在差异，业务能力与数据能力都是值得重点加强的方向。两者平均评分仅相差约0.17分，现有结果还不足以认定业务短板明显大于数据短板，因此宜作为并列重点统筹培养。')
p('在教学中，可把“理解业务—分析数据—提出改进建议”作为一项连续任务。例如，分析某病种成本时，既要理解诊疗流程及资源消耗，也要会整理数据、判断差异并与业务部门讨论改进措施。这样可以同时训练两类能力。')
page();rows=sorted(Q['23']['rows'],key=lambda x:-x['前三入选人数']);bar('talent',[x['选项'] for x in rows],[100*x['前三入选率'] for x in rows],'未来三年人才需求的覆盖面与优先顺序','来源 Q23；前三入选率表示列入前三的比例，首选率表示列为第一的比例；每项162人',[100*x['首选率'] for x in rows])
p('从需求覆盖面看，运营管理133人、数据分析120人、综合管理89人列入前三，成本与预算为83人。从第一优先选择看，运营管理67人、综合管理34人、成本与预算29人位居前三。运营管理在两种排序中都较突出，适合作为培养项目的核心应用场景；数据分析适合作为支撑多类岗位的共同能力。')
p('医保人才被42人列入需求前三，而医保课程被149人评价为较有必要。这说明“优先配置哪类人才”与“现有人员应学哪些知识”是两个问题。医保政策与支付规则宜作为复合型人才的共同学习内容，与成本、运营和绩效分析结合。')
page();h('五 课程安排与实践方式')
rows=sorted(Q['26']['rows'],key=lambda x:-x['4至5分人数']);bar('courses',[x['子项'] for x in rows],[100*x['4至5分比例'] for x in rows],'各课程模块的较高必要性评价','来源 Q26；4至5分；每项162人')
p('多项课程均获得较高必要性评价，说明受访者希望培养内容覆盖业务、管理和数据应用。课时分配可结合现有基础与岗位任务进行取舍：共同基础内容统一学习，专项方法放入具体项目中训练。')
table(['数智课程需求与现有数据工具培训','已报告现有培训','未勾选现有培训','合计'],[['较高需求','47','109','156'],['其他需求评价','2','4','6'],['合计','49','113','162']],[.46,.18,.18,.18])
p('109人同时表达较高数智课程需求且未勾选现有数据工具培训，占全体受访者67.3%，占数智高需求者69.9%。建议优先了解这部分受访者希望补充的具体内容，将需求转化为数据整理、分析解释、可视化表达和运营决策等实际任务。这里比较的是“数智课程需求”和“已有数据工具培训”两个相关题项。')
page();h('实践培养的具体组合')
rows=sorted(Q['25']['rows'],key=lambda x:-x['前三入选人数']);bar('methods',[x['选项'] for x in rows],[100*x['前三入选率'] for x in rows],'培养方式的需求覆盖面与首选情况','来源 Q25；每项162人',[100*x['首选率'] for x in rows])
p('跟岗实训125人、项目制学习95人、真实案例学习90人列入前三，分别占77.2%、58.6%和55.6%。双导师制被62人列入前三，其中33人将其列为首选，仅次于跟岗的65人。持续指导对一部分受访者具有较高优先级，可与跟岗和项目实践配套实施。')
p('70人报告已有跟岗或轮岗培训方式；72人既偏好跟岗又未报告现有相应方式，占44.4%。可优先安排可观摩、有任务、能反馈的跟岗岗位，使学员逐步从了解流程转向参与分析和形成成果。')
p('7人报告所在机构已实施双导师制，12人报告有意愿并计划一年内启动，91人报告有意愿但条件暂不具备，52人报告暂无意愿。推进时需要先明确业务导师与财务导师的分工、指导时间、工作量认可和阶段反馈要求。')
h('真实项目与基地建设可以相互支撑',2)
p('148人认为真实管理项目池对培养具有较大支持作用，147人认可实训基地的支持作用。实践基地建设方面，129人选择依托区域龙头医院建立实训基地联盟，119人选择院内设置实训岗位与教学点。建议将区域共享项目与院内实践岗位结合，形成稳定的实训入口。')
p('实战项目中，151人重视运营分析、报告撰写与决策支持，150人重视年度预算编制与执行分析，149人重视成本核算与病种盈亏分析。这些项目可优先纳入课程任务库，并根据学员基础设置不同难度。')
page();h('六 组织保障与职业发展')
rows=sorted(Q['19']['rows'],key=lambda x:-x['选择人数']);bar('problems',[x['选项'] for x in rows],[100*x['选择率'] for x in rows],'现有培训最需要改进的环节','来源 Q19；每项162人，可选择多项')
p('108人反映培训以短期集中为主、缺乏跟踪管理，占66.7%；82人反映分层分类不够、针对性不强，占50.6%。项目设计应明确学习前目标、过程辅导和培训后应用要求，让课程之间、培训与岗位之间形成连续安排。')
rows=sorted(Q['46']['rows'],key=lambda x:-x['选择人数']);bar('barriers',[x['选项'] for x in rows],[100*x['选择率'] for x in rows],'培养成果落地的主要障碍','来源 Q46；每项162人，可选择多项')
p('126人反映实践锻炼与项目历练机会不足，占77.8%；96人反映考核激励与结果运用机制不完善，占59.3%。建议在培训启动时就确定成果应用部门和评价人，使学员完成的分析报告、案例或方案能够进入实际工作。')
page();h('把组织支持落实为可执行安排')
p('152人认为考核激励与培训结果运用较为重要，151人重视经费保障，149人重视组织领导与归口管理。与此同时，153人支持建立分层分类培训体系，149人支持建立岗位胜任力评价体系。培养管理应明确“谁负责、学什么、做什么、如何评价”，并将这些要求写入年度安排。')
rows=sorted(Q['38']['rows'],key=lambda x:-x['前三入选人数']);table(['主管部门支持方向','首选人数','列入前三人数','前三入选率'],[[x['选项'],x['第1名'],x['前三入选人数'],pct(x['前三入选率'])] for x in rows],[.53,.15,.15,.17])
p('120人将纳入卫生健康人才发展规划列入政策支持前三，106人选择专项培养经费。规划与经费可以共同支持稳定的项目周期、导师队伍和实践基地，避免培养安排随单次培训结束而中断。')
h('培养成果应与职业发展机会衔接',2)
p('153人认为培养结果与职称推荐挂钩较有必要；岗位聘任、薪酬激励和人才计划推荐分别有150人给予较高必要性评价。建议建立清晰的成果标准，将实际应用、问题解决和协作表现作为评价内容，并向参与人员说明成果如何用于后续发展。')
p('职业通道评价中，跨部门轮岗与交流获得较高畅通评价的为75人，占46.3%，在各项通道中相对偏低。结合较高的跟岗需求，可优先完善跨部门交流的岗位安排、参与条件和成果要求，让学习机会与成长路径衔接。')
p('在12份实质开放意见中，7份涉及治理与组织支持，3份涉及职业发展与公平激励，3份涉及实践应用，2份涉及经费或学习实践机会，1份涉及协同与案例共享。一份意见可以涉及多个主题。这些意见进一步提示，应关注组织支持、机会分配与实践落地。')
page();h('七 分组结果与培养安排')
h('制度落实较好的受访者 更少报告缺乏系统评估',2)
p('在32名回答制度落实到位的受访者中，9人报告尚无系统评估，占28.1%；在其余130名受访者中，对应为76人，占58.5%。两组相差约30个百分点，体现出制度落实与评价安排之间较清晰的关联。')
p('管理上的启示是：培养制度与评价工具值得同步推进。制定制度时，同时明确过程记录、成果标准与跟踪反馈，能够使管理要求有具体落实载体。这一调查结果反映两者相伴出现，制度的实际效果仍应通过实施后的持续评价来检验。')
rows=[x for x in R['cross_tabs'] if x['检验家族']=='制度落实3项'];table(['调查事项','制度落实到位组','其他回答组'],[[x['结局'],f"{x['组1事件']}/{x['组1分母']}（{100*x['组1事件']/x['组1分母']:.1f}%）",f"{x['组0事件']}/{x['组0分母']}（{100*x['组0事件']/x['组0分母']:.1f}%）"] for x in rows],[.48,.26,.26])
p('其他回答组包括“有制度但落实不足”和“无系统制度安排”两类。',True)
h('先看实际任务 再确定分层方式',2)
p('本次医院类别比较尚未形成足够清晰的差异，暂不宜据此规定“某一层级医院就应采用某一种培养方式”。更实用的安排是先了解学员的业务任务、数据基础、可用学习时间和实践条件，再组合线上学习、跟岗、项目和导师指导。')
p('管理岗位与其他岗位也可以共用业务理解和数据应用的基础课程，再按职责深化。管理人员增加协同决策、项目管理和团队带教任务；具体执行岗位加强数据处理、流程分析和改进方案形成。该安排是实施建议，具体内容应结合岗位需要确定。')
h('按成长阶段安排任务',2)
p('103人认为合理培养周期为3至5年，占63.6%。分层培养方面，新入职人员、业务骨干、中层管理人员和领军人才对应培养重点的较高认同人数分别为140、145、145和148人。可据此建立逐步进阶的任务体系：新入职人员掌握流程与规范，骨干深化专项分析，中层训练协同与带教，领军人才加强战略与系统治理。')
h('核心方向可先落地 具体强度按人群调整',2)
p('复核不同答卷组合后，数智课程、跟岗实践和持续跟踪仍是值得关注的方向。不同地区构成下，数据能力高差距比例有所变化，提示各地在安排课时和难度时，应进一步了解本地学员基础。可统一培养框架，同时保留课程深度和实践任务的调整空间。')
page();h('八 项目实施建议')
h('第一步 确定项目与参与人员',2)
p('由培养归口部门组织财务、运营、医保、临床和信息部门共同确定试点任务。建议先选取2至3个能够获得数据和业务配合的项目，例如预算执行偏差分析、病种成本与运营分析、医保精细化管理。每个项目明确要解决的问题、业务联系人和预期成果。')
p('选拔参与人员时，可综合考虑实际岗位任务、学习基础和应用机会。对不同基础的学员安排递进任务，让新入职人员、骨干与管理人员在同一项目中承担相适应的职责。')
h('第二步 把课程嵌入项目过程',2)
p('项目开始前学习相关业务流程与制度；执行过程中学习数据整理、分析和表达方法；阶段结束后进行案例复盘和方案讨论。由业务导师解释场景与流程，由财务或数据导师指导分析方法，使理论学习与实际问题相互连接。')
p('线上内容适合支持基础知识学习和重复练习，集中实训用于需要协作和指导的任务，跟岗用于理解实际流程。具体比例根据岗位和项目条件确定。')
h('第三步 用成果检验学习进展',2)
table(['阶段','具体安排','可查看的成果'],[
['启动','明确业务问题与学习目标','任务说明、基线情况和项目计划'],
['实施','开展导师反馈与阶段讨论','数据整理记录、阶段分析和修改记录'],
['结项','业务部门与导师共同评审','分析报告、案例或改进方案'],
['应用','将成果用于实际管理','采纳情况、使用部门反馈和应用记录'],
['跟踪','持续检查应用效果与后续需求','同口径业务指标、复盘记录和下一阶段任务']],[.16,.41,.43])
p('评价既看学员是否完成任务，也看成果是否进入实际工作。可优先记录报告质量、建议采纳、实际应用和部门反馈，再结合项目特点观察业务指标变化。实施中的问题应及时反馈到课程和导师安排中。')
h('第四步 建立持续培养安排',2)
p('将年度课程、实践岗位、导师指导和项目评价纳入统一安排；把成熟案例沉淀为案例库，把适合重复训练的任务形成项目清单。对成效较好的试点逐步扩大，对参与困难或应用不足的环节调整资源和组织方式。')
p('总体而言，本次调查支持以业务与数据能力为共同重点，以运营管理项目为主要应用场景，以跟岗、案例和导师指导为支撑，并通过持续评价促进成果运用。培养质量的提升，需要课程内容、实践机会和组织保障同步推进。')
page();h('附录A 各题统计结果')
p('本附录按原题顺序列出全部题目。除Q11、Q12和Q47专门分母外，表中人数均为答卷数。量表分布依次为1至5分人数，高分为4至5分；Q22与Q35含义不同，必须连同题目锚点阅读。多选和排序选项保留原始术语，其他项的自由填写内容不公开。',True)
for qi in range(1,48):
    q=Q[str(qi)];h(f'Q{qi} '+q['title'],2);rr=q['rows'];kind=q['type']
    if kind in ['单选','地域']:
        table(['选项','人数','分母','比例'],[[x['选项'],x['人数'],x['分母'],pct(x['比例'])] for x in rr],[.55,.15,.15,.15])
    elif kind=='是非矩阵':
        table(['项目','是','否','分母','是比例'],[[x['项目'],x['是'],x['否'],x['分母'],pct(x['是比例'])] for x in rr],[.5,.12,.12,.12,.14])
    elif kind=='多选':
        table(['选项','选择人数','分母','选择率'],[[x['选项'],x['选择人数'],x['分母'],pct(x['选择率'])] for x in rr],[.55,.15,.15,.15])
    elif kind=='前三排序':
        table(['选项','第1','第2','第3','前三人数','首选率','前三率'],[[x['选项'],x['第1名'],x['第2名'],x['第3名'],x['前三入选人数'],pct(x['首选率']),pct(x['前三入选率'])] for x in rr],[.39,.08,.08,.08,.12,.12,.13])
    elif kind=='五级量表':
        table(['子项','1至5分人数','均值±标准差','4至5分 n/N','高分比例'],[[x['子项'],' / '.join(str(x[f'{k}分']) for k in range(1,6)),f"{x['均值']:.2f}±{x['标准差']:.2f}",f"{x['4至5分人数']}/{x['有效数']}",pct(x['4至5分比例'])] for x in rr],[.42,.20,.14,.13,.11])
    elif kind=='选填人数':
        def short(s):return re.sub(r'^\(\d+\)人[; 、]*','',s).replace('___','').replace('人  （如不清楚，可不填写）','').replace('人 （如不清楚，可不填写）','')
        table(['项目','填报记录数','记录计数和','中位数','最大值'],[[('在岗总人数' if qi==11 and ix==0 else '正高级专业技术资格' if qi==12 and ix==0 else short(x['项目'])),x['有效填报数'],f"{x['计数合计']:.0f}",f"{x['中位数']:.1f}",f"{x['最大值']:.0f}"] for ix,x in enumerate(rr)],[.46,.15,.15,.12,.12])
    else:
        table(['主题','涉及意见数','实质意见分母','意见内比例'],[[x['主题'],x['涉及意见数'],x['实质意见分母'],pct(x['意见内比例'])] for x in rr],[.43,.19,.20,.18])
    if qi==11:p('本题按各字段实际填报记录统计。记录计数和为填写数值之和，不作为去重后的人员规模或整体人员结构。',True)
    elif qi==12:p('同一人持有多项资格可分别计入。各项按实际填报记录统计，资格计数不相加为独立持证人数。',True)
    p('数据来源  '+q['source'],True)
page();h('附录B 统计方法与比较结果')
h('Q22全部配对比较',2)
table(['维度对','均值差','95%区间','精确p','10对BH q'],[[x['维度1'].split(':')[0]+' / '+x['维度2'].split(':')[0],f"{x['均值差']:.3f}",f"{x['均值差95下限']:.3f} 至 {x['均值差95上限']:.3f}",pf(x['精确符号置换p']),pf(x['BH q'])] for x in R['pairwise']],[.35,.13,.24,.14,.14])
p('差值方向为表内第一维度减第二维度；区间未作多重比较调整。区间与精确检验采用不同方法，在临界值附近可能产生轻微边界差异，应以完整方法与效应大小解释。',True)
for fam in ['医院类别12项','职务分组12项','制度落实3项']:
    h(fam,2);rows=[x for x in R['cross_tabs'] if x['检验家族']==fam];p('比较方向  '+rows[0]['组1']+' 减 '+rows[0]['组0'],True,True)
    table(['结局','组1 n/N','组0 n/N','差值百分点','p','BH q'],[[x['结局'],f"{x['组1事件']}/{x['组1分母']}",f"{x['组0事件']}/{x['组0分母']}",f"{100*x['比例差']:.1f}",pf(x['Fisher双侧p']),pf(x['BH q'])] for x in rows],[.31,.16,.16,.15,.11,.11])
h('统计口径与复现说明',2)
p('正文人数以162名受访者为基础，不作为独立医院数量或全国总体估计。单选与多选按选择人数统计；量表报告各分值人数与均值；排序分别统计首选和前三入选。第11、12题按字段统计实际填报记录，保留零值；选答题未填写不影响其他题目的分析。',True)
p('二元比例区间使用Wilson方法；分组比较使用双侧Fisher精确检验，比例差区间使用Newcombe方法。医院类别12项、职务12项、制度落实3项分别进行BH多重比较校正；区间未作多重比较调整。分组结果用于观察关联，未作因果解释。',True)
p(f"Q22五维比较采用Friedman检验，统计量{R['friedman']['统计量']:.2f}，p={pf(R['friedman']['p'])}，Kendall W={R['friedman']['Kendall W']:.3f}。10对维度比较采用精确符号翻转置换并共同BH校正；均值差区间采用配对t近似。评分按近似等距处理，置换检验要求零假设下差值符号可交换。",True)
p('原始数值版与文本版按答卷序号对齐，32562个实质字段单元格核验一致。两份文件属于同一批162份答卷。分析脚本和聚合统计保存在配套复现包中；完整计算与核验记录见统计工作簿。',True)
p('复现入口：analyze.py读取原始两个导出文件并生成聚合JSON与CSV；build_report.py根据聚合数据生成本报告；export_aggregate_xlsx.py导出统计表。运行环境和步骤见复现包说明。公开附件仅含汇总结果，原始答卷由数据持有人自行保管。',True)

def footer_pdf(canvas,dd):
    canvas.saveState();canvas.setFont('STSong-Light',8);canvas.setFillColor(colors.HexColor('#596674'))
    canvas.drawString(57,27,'卫生健康经济管理人才培养调查  |  公开汇总版')
    canvas.drawRightString(A4[0]-57,27,str(dd.page));canvas.restoreState()
pdfpath=OUT/'卫生健康经济管理人才培养调查完整报告.pdf';docxpath=OUT/'卫生健康经济管理人才培养调查完整报告.docx'
pdf=SimpleDocTemplate(str(pdfpath),pagesize=A4,rightMargin=57,leftMargin=57,topMargin=47,bottomMargin=45,title='卫生健康经济管理人才培养调查完整报告',author='调查分析',pageCompression=1)
pdf.build(story,onFirstPage=footer_pdf,onLaterPages=footer_pdf)
doc.save(docxpath);(ROOT/'work/report_text.txt').write_text('\n\n'.join(plain),encoding='utf-8')
print(json.dumps({'pdf':str(pdfpath),'docx':str(docxpath),'paragraphs':len(plain)},ensure_ascii=False))
