# 问卷分析复现说明

本包面向持有原始问卷导出的研究人员。所有附带数据均为聚合统计，不含原始Excel、答卷序号、IP、时间、逐人完整矩阵或开放意见原文。

## 复现边界

- 本研究为同一批162份答卷的两种导出，数值版207列、文本版129列，共47题。
- 主样本保留全部162份。Q11/Q12为选答，不因缺失整份剔除。
- 无医院唯一标识，不能推断162家独立医院或全国总体。
- 公开包中的小样本区间与检验均是模型条件下探索性结果。
- 正式PDF由ReportLab生成，Word由python-docx生成；内容一致，分页可不同。
- portable Excel导出可复现数值与全部题表，不保证与正式JS工作簿排版逐像素一致。

## 环境

Python 3.10及以上。依赖见requirements.txt。生成中文图表需Noto Sans CJK字体；Linux常见路径为 /usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc。其他系统可修改build_report.py中的字体路径。PDF正文使用ReportLab内置中文CID字体。读取Excel只在本地进行。

## 完整重算

把原始数值版与文本版保存在你自己的私有目录，不要上传到公共仓库。

1. python analyze.py --numeric "私有目录/数值版.xlsx" --text "私有目录/文本版.xlsx" --out work
2. python build_report.py work/aggregate_tables.json deliverables
3. python export_aggregate_xlsx.py work/aggregate_tables.json deliverables/复现统计.xlsx

如只需从已公开聚合表重建报告，可运行：

python build_report.py aggregate/aggregate_tables.json deliverables

## 主要计算

- 单选/多选：人数与对应分母；多选比例可合计超过100%。
- 排序：第1、2、3名分别计数，前三率与首选率独立；3-2-1加权分仅描述。
- 量表：完整1至5分分布、均值、标准差、中位数、高低分比例；不把不同方向量表合并。
- 区间：Wilson比例区间；Newcombe独立两比例差区间；配对均值差t近似区间。
- 组间检验：双侧Fisher；家族为医院类别12、职务12、制度落实3、Q11可用性6，分别BH校正。
- 同人五维比较：Friedman与Kendall W；全部10对精确符号翻转置换，10对BH校正。
- Q11：按列有效非负整数；空白与非空无效分开；总数、去大值、分项和条件与IQR条件均为敏感性，不认定去重总体。
- Q47：关键词辅助并人工复核的多标签编码。只输出主题汇总，不输出参与者逐人主题矩阵。

## 管理汇报修订版

本次仅调整报告表达与章节组织，已核验的统计数据保持不变。正文围绕调查发现与管理建议展开，检验方法和数值放入技术附录。保留各题统计，选答人数表按实际填报记录呈现。报告生成脚本已同步更新。

## 输出检查

analyze.py会输出32562格跨导出核验、全部47题、主分析和敏感性统计。现有输入重算结果为0格不一致，八个关键基准全部一致。独立程序另对33个交叉比较和10个配对检验等共374项数值进行验证。

发布前检查：只共享aggregate、脚本、报告及汇总工作簿，禁止把私有输入或work目录整体打包。report_text.txt及页面PNG仅用于内部排版检查，不是必要交付文件。
